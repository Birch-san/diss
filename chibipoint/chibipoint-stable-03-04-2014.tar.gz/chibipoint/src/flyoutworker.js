onmessage = function (oEvent) {
  console.log("Called back by the worker!\n");
};